<h1>Hello world!</h1>

<textarea style="width: 80%; height: 10em;">
This is an example template for the HelloPlugin.
</textarea>
